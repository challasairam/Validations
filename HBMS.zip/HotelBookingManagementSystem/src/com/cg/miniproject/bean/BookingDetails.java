package com.cg.miniproject.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table(name="bookingdetails")
public class BookingDetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="booking_id")
	private Integer bookingId;
	@Column(name="room_id")
	private Integer roomId;
	@Column(name="user_id")
	private Integer userId;
	public Date getBookedFrom() {
		return bookedFrom;
	}

	public void setBookedFrom(Date bookedFrom) {
		this.bookedFrom = bookedFrom;
	}

	public Date getBookedTo() {
		return bookedTo;
	}

	public void setBookedTo(Date bookedTo) {
		this.bookedTo = bookedTo;
	}



	@Column(name="booked_from")
	private Date bookedFrom;
	@Column(name="booked_to")
	private Date bookedTo;
	@Column(name="no_of_adults")
	private Integer noOfAdults;
	@Column(name="no_of_children")
	private Integer noOfChildren;
	@Column(name="amount")
	private Double amount;
	@Transient
	private String bookedFromDate;
	@Transient
	private String bookedToDate;
	public Integer getBookingId() {
		return bookingId;
	}

	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}

	public Integer getRoomId() {
		return roomId;
	}

	public void setRoomId(Integer roomId) {
		this.roomId = roomId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getBookedFromDate() {
		return bookedFromDate;
	}

	public void setBookedFromDate(String bookedFromDate) {
		this.bookedFromDate = bookedFromDate;
	}

	public String getBookedToDate() {
		return bookedToDate;
	}

	public void setBookedToDate(String bookedToDate) {
		this.bookedToDate = bookedToDate;
	}

	public Integer getNoOfAdults() {
		return noOfAdults;
	}

	public void setNoOfAdults(Integer noOfAdults) {
		this.noOfAdults = noOfAdults;
	}

	public Integer getNoOfChildren() {
		return noOfChildren;
	}

	public void setNoOfChildren(Integer noOfChildren) {
		this.noOfChildren = noOfChildren;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	

	public BookingDetails() {

	}

	@Override
	public String toString() {
		return "BookingDetails [bookingId=" + bookingId + ", roomId=" + roomId
				+ ", userId=" + userId + ", bookedFrom=" + bookedFrom
				+ ", bookedTo=" + bookedTo + ", noOfAdults=" + noOfAdults
				+ ", noOfChildren=" + noOfChildren + ", amount=" + amount
				+ "]";
	}
	
}
