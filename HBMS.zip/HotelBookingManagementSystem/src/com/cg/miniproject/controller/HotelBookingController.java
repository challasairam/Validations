package com.cg.miniproject.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.engine.transaction.jta.platform.internal.JOTMJtaPlatform;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.bean.User;
import com.cg.miniproject.exception.HotelException;
import com.cg.miniproject.service.IHotelBookingService;

@Controller("/hbms")
public class HotelBookingController {
	@Autowired
	IHotelBookingService service;

	@RequestMapping("index")
	public ModelAndView getHomePage() {
		ModelAndView view = new ModelAndView();
		view.setViewName("home");
		return view;
	}

	@RequestMapping("login")
	public ModelAndView getLoginPage() {
		ModelAndView view = new ModelAndView("login", "user1", new User());
		ArrayList<String> roles = new ArrayList<String>();
		roles.add("User");
		roles.add("Employee");
		roles.add("Admin");
		view.addObject("roles", roles);
		return view;
	}

	@RequestMapping("register")
	public ModelAndView getRegisterPage() {
		ModelAndView view = new ModelAndView("register", "user", new User());
		ArrayList<String> roles = new ArrayList<String>();
		roles.add("User");
		roles.add("Employee");
		roles.add("Admin");
		view.addObject("roles", roles);
		return view;
	}

	@RequestMapping(value = "registerDetails", method = RequestMethod.POST)
	public ModelAndView storeDetails(@ModelAttribute("user") @Valid User user,
			BindingResult result) {
		ModelAndView view = new ModelAndView();
		if (result.hasErrors()) {
			view = new ModelAndView("register", "user", user);
			ArrayList<String> roles = new ArrayList<String>();
			roles.add("User");
			roles.add("Employee");
			roles.add("Admin");
			view.addObject("roles", roles);
		} else {
			try {
				boolean res = service.register(user);
				if (res) {
					System.out.println("success");
				} else {
					System.out.println("failure");
				}
			} catch (HotelException e) {
			}
			view.setViewName("home");

		}
		return view;

	}

	@RequestMapping(value = "fetchLoginDetails", method = RequestMethod.POST)
	public ModelAndView getDetails(@ModelAttribute("user1") @Valid User user,
			BindingResult result, HttpServletRequest request) {
		HttpSession session = request.getSession();
		ModelAndView view = new ModelAndView();

		System.out.println("Login Page");
		if (result.hasErrors()) {
			view = new ModelAndView("login", "user1", user);
			view.addObject("message", "Login Failed");

		} else {
			try {
				if (user.getUserName().equals("admin"))
					user.setRole("Admin");
				else
					user.setRole("User");
				User user1 = service.login(user);

				if (null != user1) {
					session.setAttribute("username", user1.getUserName());
					if (user.getRole().equals("Admin")) {
						view = new ModelAndView("DisplayForAdmin", "hotel",
								new Hotel());
					} else {

						ArrayList<Hotel> hotels = service.getHotelList();

						if (!hotels.isEmpty()) {
							view = new ModelAndView("DisplayForUser", "room",
									new RoomDetails());
							view.addObject("hotelList", hotels);

						} else {
							String msg = "No hotels are available for Booking!";
							view.addObject("msg", msg);
						}

					}
				} else {
					view = new ModelAndView("login", "user1", user);
					view.addObject("message", "Login Failed");
				}

			} catch (HotelException e) {

			}

		}
		return view;

	}

	@RequestMapping("getRoomDetails")
	public ModelAndView getRoomDetails(
			@ModelAttribute("room") RoomDetails details) {
		ModelAndView view = new ModelAndView();
		try {
			ArrayList<RoomDetails> list = service.getRoomDetails(details
					.getHotelId());
			System.out.println(list);
			if (!list.isEmpty()) {
				ArrayList<Hotel> hotels = service.getHotelList();
				view = new ModelAndView("DisplayForUser", "room",
						new RoomDetails());
				view.addObject("hotelList", hotels);
				view.addObject("roomDetails", list);

			}
			else
			{
				
			}

		} catch (HotelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return view;

	}

	@RequestMapping("AddHotel")
	public ModelAndView getAddHotelPage() {
		ModelAndView view = new ModelAndView("AddHotel", "hotel", new Hotel());
		return view;

	}

	@RequestMapping("addHotelDetails")
	public ModelAndView saveHotelDetails(
			@ModelAttribute("hotel") @Valid Hotel hotel, BindingResult result) {

		ModelAndView view = new ModelAndView();
		if (result.hasErrors()) {
			view = new ModelAndView("AddHotel", "hotel", hotel);
		} else {
			try {
				boolean result2 = service.addHotels(hotel);
				if (result2) {
					view = new ModelAndView("DisplayForAdmin", "hotel",
							new Hotel());
				}

			} catch (HotelException e) {

			}
		}
		return view;

	}

	@RequestMapping("DeleteHotel")
	public ModelAndView getDeleteHotelPage() {
		ModelAndView view = new ModelAndView("DeleteHotel", "hotel",
				new Hotel());
		return view;

	}

	@RequestMapping("deleteHotelDetails")
	public ModelAndView deleteHotelDetails(@ModelAttribute("hotel") Hotel hotel) {
		ModelAndView view = new ModelAndView();
		try {
			boolean result = service.deleteHotel(hotel.getHotelId());
			if (result) {
				view = new ModelAndView("DisplayForAdmin", "hotel", new Hotel());
			}
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return view;

	}

	@RequestMapping("ModifyHotel")
	public ModelAndView getModifyHotelPage() {
		ModelAndView view = new ModelAndView("ModifyHotel", "hotel",
				new Hotel());
		return view;

	}

	@RequestMapping("modifyHotelDetails")
	public ModelAndView modifyHotelDetails(
			@ModelAttribute("hotel") @Valid Hotel hotel, BindingResult result) {
		System.out.println(hotel.getHotelId());
		ModelAndView view = new ModelAndView();
		if (result.hasErrors()) {
			view = new ModelAndView("ModifyHotel", "hotel", hotel);
		} else {
			try {
				boolean result2 = service.modifyHotel(hotel);
				if (result2) {
					view = new ModelAndView("DisplayForAdmin", "hotel",
							new Hotel());
				}
			} catch (HotelException e) {

			}
		}

		return view;

	}

	@RequestMapping("getHotelDetailsById")
	public ModelAndView getHotelDetailsById(@ModelAttribute("hotel") Hotel hotel) {

		ModelAndView view = new ModelAndView();
		ArrayList<Hotel> list = service.getHotelList(hotel.getHotelId());
		// System.out.println(list);
		if (!list.isEmpty()) {
			view = new ModelAndView("ModifyHotel", "hotel", new Hotel());
			view.addObject("hotelDetails", list);
		}
		return view;

	}

	@RequestMapping("ViewHotelList")
	public ModelAndView getHotelList() {
		ModelAndView view = new ModelAndView();
		try {
			ArrayList<Hotel> list = service.getHotelList();
			if (!list.isEmpty()) {
				view.addObject("hotelList", list);
				view.setViewName("ViewHotelList");
			} else {
				view.addObject("errorMessage", "No hotels to display");
				view.setViewName("ViewHotelList");
			}
		} catch (HotelException e) {

		}
		return view;

	}

	@RequestMapping("ViewBooking")
	public ModelAndView getBookingsPage() {
		ModelAndView view = new ModelAndView("ViewBooking", "hotel",
				new Hotel());

		return view;

	}

	@RequestMapping("getBookingDetailsById")
	public ModelAndView getBookingDetailsById(
			@ModelAttribute("hotel") Hotel hotel) {
		ModelAndView view = new ModelAndView();
		try {
			ArrayList<BookingDetails> list = service.retrieveBookings(hotel
					.getHotelId());
			if (!list.isEmpty()) {
				view.addObject("bookingDetails", list);
				view.setViewName("ViewBooking");
			} else {
				view.addObject("errorMessage",
						"No Bookings found for given Hotel Id");
				view.setViewName("ViewBooking");
			}

		} catch (HotelException e) {
		}

		return view;

	}

	@RequestMapping("ViewGuestList")
	public ModelAndView getGuestListPage() {
		ModelAndView view = new ModelAndView("ViewGuestList", "hotel",
				new Hotel());

		return view;

	}

	@RequestMapping("getGuestList")
	public ModelAndView getGuestListById(@ModelAttribute("hotel") Hotel hotel) {
		ModelAndView view = new ModelAndView();
		try {
			BookingDetails details = service.retrieveGuestList(hotel
					.getHotelId());
			System.out.println(details);
			ArrayList<BookingDetails> list = null;

			if (null != details) {
				list = new ArrayList<BookingDetails>();
				list.add(details);
				view.addObject("guestList", list);
				view.setViewName("ViewGuestList");
			} else {
				view.addObject("errorMessage",
						"No Guest List found for given Hotel Id");
				view.setViewName("ViewGuestList");
			}

		} catch (HotelException e) {
		}

		return view;

	}

	@RequestMapping("ViewSpecificBooking")
	public ModelAndView getBookingDetailsPage() {
		ModelAndView view = new ModelAndView("ViewSpecificBooking", "booking",
				new BookingDetails());

		return view;

	}

	@RequestMapping("getBookingDetailsByDate")
	public ModelAndView getBookingDetailsByDate(
			@RequestParam("currentDate") String date) {
		ModelAndView view = new ModelAndView();
		try {
			DateTimeFormatter formatter = DateTimeFormatter
					.ofPattern("dd/MM/yyyy");
			LocalDate currentDate = LocalDate.parse(date, formatter);

			ArrayList<BookingDetails> list = service
					.retrieveBookings(currentDate);
			if (!list.isEmpty()) {
				view.addObject("bookingDetails", list);
				view.setViewName("ViewSpecificBooking");
			} else {
				view.addObject("errorMessage",
						"No Bookings found for given Date");
				view.setViewName("ViewSpecificBooking");
			}

		} catch (HotelException e) {

		}

		return view;

	}
	
	
/*
 * Room Details
 */
	@RequestMapping("AddRoom")
	public ModelAndView getAddRoomPage() {
		ModelAndView view = new ModelAndView("AddRoom", "room",
				new RoomDetails());
		ArrayList<String> type = new ArrayList<String>();
		type.add("Standard non A/C room");
		type.add("Standard A/C room");
		type.add("Executive A/C room");
		type.add("Deluxe A/C room");
		view.addObject("type", type);
		return view;

	}

	@RequestMapping("addRoomDetails")
	public ModelAndView saveRoomDetails(
			@ModelAttribute("room") @Valid RoomDetails roomDetails,
			BindingResult result) {

		ModelAndView view = new ModelAndView();

		if (result.hasErrors()) {
			ArrayList<String> type = new ArrayList<String>();
			type.add("Standard non A/C room");
			type.add("Standard A/C room");
			type.add("Executive A/C room");
			type.add(" Deluxe A/C room");
			view.addObject("type", type);
			view = new ModelAndView("AddRoom", "room", roomDetails);
		} else {

			try {

				boolean result1 = service.validateHotelId(roomDetails
						.getHotelId());
				System.out.println("validated");
				if (result1) {
					boolean result2 = service.addRooms(roomDetails);
					System.out.println("added successfull");
					view = new ModelAndView("DisplayForAdmin", "hotel",
							new Hotel());
					if (result2) {
						String msg = "Added Successfully";
						view.addObject("msg", msg);

					}

				}

			} catch (HotelException e) {

			}
		}
		return view;

	}

	@RequestMapping("DeleteRoom")
	public ModelAndView getDeleteRoomPage() {
		ModelAndView view = new ModelAndView("DeleteRoom", "room",
				new RoomDetails());
		return view;

	}

	@RequestMapping("deleteRoomDetails")
	public ModelAndView deleteRoomDetails(
			@ModelAttribute("room") RoomDetails roomDetails) {
		ModelAndView view = new ModelAndView();
		try {
			boolean result = service.deleteRoom(roomDetails.getRoomId());
			if (result) {
				view = new ModelAndView("DisplayForAdmin", "hotel", new Hotel());
			}
		} catch (HotelException e) {
			// TODO Auto-generated catch block
		}
		return view;

	}

	@RequestMapping("ModifyRoom")
	public ModelAndView getModifyRoomPage() {
		ModelAndView view = new ModelAndView("ModifyRoom", "room",
				new RoomDetails());
		return view;

	}

	@RequestMapping("getDetailsById")
	public ModelAndView getDetailsById(
			@ModelAttribute("room") RoomDetails roomDetails) {

		ModelAndView view = new ModelAndView();
		ArrayList<RoomDetails> list = service.getRoomList(roomDetails);

		// System.out.println(list);
		if (!list.isEmpty()) {
			view = new ModelAndView("ModifyRoom", "room", new RoomDetails());
			view.addObject("roomDetails", list);
		}
		return view;
	}

	@RequestMapping("modifyRoomDetails")
	public ModelAndView modifyRoomDetails(
			@ModelAttribute("room") @Valid RoomDetails roomDetails,
			BindingResult result) {
		// System.out.println(hotel.getHotelId());
		ModelAndView view = new ModelAndView();
		if (result.hasErrors()) {
			view = new ModelAndView("ModifyRoom", "room", roomDetails);
		} else {
			try {
				boolean result2 = service.modifyRoom(roomDetails);
				if (result2) {
					view = new ModelAndView("DisplayForAdmin", "hotel",
							new Hotel());
				}
			} catch (HotelException e) {

			}
		}

		return view;
	}

}